namespace SEN381_API_Group3.models;

public class IndividualPolicy: Policy{
    public IndividualPolicy(){}
}