namespace SEN381_API_Group3.models;

public class FamilyPolicy: Policy{
    public FamilyPolicy(){}
}